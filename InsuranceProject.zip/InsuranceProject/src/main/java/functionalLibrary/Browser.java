package functionalLibrary;

public enum Browser {
  
	InternerExplorer,
	Chrome,Firefox,Edge,Safari,IOS,Andriod;
	
}
