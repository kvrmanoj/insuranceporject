package functionalLibrary;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;


public class PropertyManager {
	static Properties property= new Properties();
	
	static {
		String projectDirectory=System.getProperty("user.dir");
		
		try {
			FileInputStream fis=new FileInputStream(projectDirectory+"Config.properties");property.load(fis);} 
			catch (IOException e) {
			}
	}
	
	public static String get(String key) {
		return property.getProperty(key).toString();
	}
	
	public static void set(String key,String value) {
		 property.setProperty(key,value);
	}
	
	
	
	
	
	
    
}
