package functionalLibrary;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExceltUtil {
	
	static XSSFWorkbook workBook;
	XSSFSheet sheet;
	static HashMap<String,String> testdata=new HashMap<String, String>();
	public static HashMap<String,String> getTestData() throws Exception{
		workBook=new XSSFWorkbook(new FileInputStream("src\\test\\resources\\testdata.xlsx"));
		XSSFSheet sheet=workBook.getSheet("Sheet1");
		
		return testdata;
	}

}
