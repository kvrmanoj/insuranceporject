package functionalLibrary;

import java.util.InputMismatchException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;

public class DriverConfig {

	WebDriver driver;
	public WebDriver getDriver(Browser browser) {
	     
		switch(browser){
		case Chrome:
			String path=System.getProperty("user.dir");
			System.setProperty("webdriver.chrome.driver", path+"//chromedriver");						
			driver=new ChromeDriver();
			break;
		case Firefox:
	
			driver=new FirefoxDriver();
		case Edge:	
			 driver=new EdgeDriver();
			break;
		case InternerExplorer:
			driver=new InternetExplorerDriver();	
			break;
		case Safari:
			driver=new SafariDriver();
			break;
		case IOS:
		    throw new InputMismatchException("IOS is not supoorted in local test execution ");
		case Andriod:
			throw new InputMismatchException("Andriod is not supoorted in local test execution ");
		}
		return driver;
		
	}
	
}
