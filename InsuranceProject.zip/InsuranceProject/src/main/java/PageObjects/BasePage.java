package PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {
	WebDriver driver;
	
   public BasePage(WebDriver driver) {
	    
		this.driver=driver;
	}
	
	
	public WebElement getElement(By locator) {
		waitFortTheElementPresent(locator);
		return driver.findElement(locator);
	}
	
	public void selectByVisibleText(By locator,String value) {
		Select select=new Select(driver.findElement(locator));
		select.selectByVisibleText(value);	
	}
	
	public void selectByValue(By locator,String value) {
		Select select=new Select(driver.findElement(locator));
		select.selectByValue(value);	
	}
	
	public void selectByIndex(By locator,int index) {
		Select select=new Select(driver.findElement(locator));
		select.selectByIndex(index);	
	}

	public List getElements(By locator) {
		return driver.findElements(locator);
	}

	public String getTitle() {
		return driver.getTitle();
	}

	
	public void waitFortTheElementPresent(By locator) {
		WebDriverWait wait=new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(locator)));
	}

	
	

}
