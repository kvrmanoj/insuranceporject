package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage extends BasePage{

	 By usernam=By.id("username");
	 By Password=By.id("password");
	 By filetypeloc=By.xpath("");
	
	 public LoginPage(WebDriver driver) {
		super(driver);	
	}
	
	public void dologin(String username,String pwd) {
		getElement(usernam).sendKeys(username);
		getElement(usernam).sendKeys(pwd);
	}
	
	
	

}
