package tests;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import functionalLibrary.*;

public class BaseTest {
	
		WebDriver driver;
		HashMap<String,String> testdata=new HashMap<String, String>();
		@BeforeTest
		public void setup() {
			DriverConfig driverconfig=new DriverConfig();
			driver=driverconfig.getDriver(Browser.valueOf(PropertyManager.get("Browser")));
			driver.get(PropertyManager.get("url"));		
		}
		
		
		@AfterTest
		public void tearDown() {
			driver.quit();
		}
		
}
