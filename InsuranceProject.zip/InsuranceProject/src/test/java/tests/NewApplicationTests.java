package tests;

import org.testng.annotations.Test;

import PageObjects.*;
import functionalLibrary.PropertyManager;

public class NewApplicationTests extends BaseTest{
	
	HomePage homepage;
	LoginPage login;
	
	
	@Test
	public void MakeNewApplication() {
		login=new LoginPage(driver);
		login.dologin(PropertyManager.get("username") ,testdata.get("password"));
		homepage.clickNewAppButton();
	}

}
